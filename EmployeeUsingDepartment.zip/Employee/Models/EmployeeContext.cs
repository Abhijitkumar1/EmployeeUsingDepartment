﻿using Microsoft.EntityFrameworkCore;

namespace Employee.Models
{
    public class EmployeeContext: DbContext
    {

        public EmployeeContext(DbContextOptions<EmployeeContext> options) : base(options) { }

        public DbSet<Department> Departments { get; set; }
        public DbSet<Employe> Employees { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    // Configure relationships and constraints if needed
        //    modelBuilder.Entity<Employee>()
        //        .HasOne(e => e.Department)
        //        .WithMany(d => d.Employees)
        //        .HasForeignKey(e => e.DepartmentId);

        //    base.OnModelCreating(modelBuilder);
        //}


    }
}
